

set -ex



command -v "${PREFIX}/bin/caffe"
command -v "${PREFIX}/bin/classification"
command -v "${PREFIX}/bin/classify"
command -v "${PREFIX}/bin/compute_image_mean"
command -v "${PREFIX}/bin/convert_cifar_data"
command -v "${PREFIX}/bin/convert_imageset"
command -v "${PREFIX}/bin/convert_mnist_data"
command -v "${PREFIX}/bin/convert_mnist_siamese_data"
command -v "${PREFIX}/bin/detect"
command -v "${PREFIX}/bin/device_query"
command -v "${PREFIX}/bin/draw_net"
command -v "${PREFIX}/bin/extract_features"
command -v "${PREFIX}/bin/finetune_net"
command -v "${PREFIX}/bin/net_speed_benchmark"
command -v "${PREFIX}/bin/test_net"
command -v "${PREFIX}/bin/train_net"
command -v "${PREFIX}/bin/upgrade_net_proto_binary"
command -v "${PREFIX}/bin/upgrade_net_proto_text"
command -v "${PREFIX}/bin/upgrade_solver_proto_text"
test -d "${PREFIX}/include/caffe"
test -f "${PREFIX}/lib/libcaffe.so"
exit 0
