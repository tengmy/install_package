#!/bin/bash

#SBATCH --workdir /home/mohan./caffe_experiments/AWS_FRESH_RUN/experiment_configs/alexnet/color-20-80/train_from_scratch/results
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 2
#SBATCH --mem 16384
#SBATCH --time 23:59:59
#SBATCH --partition gpu
#SBATCH --gres gpu:1
#SBATCH --qos gpu


#module load anaconda
#source activate mohanty
echo STARTING AT `date`

python results/parse_log.py ./caffe.log results/parsed_caffe_output
python results/generate_graphs.py

echo FINISHED at `date`

