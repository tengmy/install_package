print("import: 'caffe'")
import caffe

